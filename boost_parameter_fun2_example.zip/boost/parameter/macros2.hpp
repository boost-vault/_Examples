// Copyright (C) 2006 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_PARAMETER_MACROS2_HPP
#define BOOST_PARAMETER_MACROS2_HPP

#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/arithmetic/dec.hpp>
#include <boost/preprocessor/logical/bool.hpp>
#include <boost/preprocessor/logical/bitand.hpp>
#include <boost/preprocessor/logical/bitor.hpp>
#include <boost/preprocessor/logical/bitxor.hpp>
#include <boost/preprocessor/logical/compl.hpp>
#include <boost/preprocessor/comparison/equal.hpp>
#include <boost/preprocessor/comparison/not_equal.hpp>
#include <boost/preprocessor/control/iif.hpp>
#include <boost/preprocessor/control/while.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/for.hpp>
#include <boost/preprocessor/facilities/empty.hpp>
#include <boost/preprocessor/seq/seq.hpp>
#include <boost/preprocessor/seq/push_back.hpp>
#include <boost/preprocessor/seq/size.hpp>
#include <boost/preprocessor/seq/elem.hpp>
#include <boost/preprocessor/tuple/elem.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/parameter/macros.hpp>

// Usage:
// BOOST_PARAMETER_SEQ_ZERO(3) yields (0)(0)(0)

#define BOOST_PARAMETER_SEQ_ZERO_NEXT_STATE(d, state) \
    ( \
        BOOST_PP_SEQ_PUSH_BACK(BOOST_PP_TUPLE_ELEM(2, 0, state), 0) \
      , BOOST_PP_DEC(BOOST_PP_TUPLE_ELEM(2, 1, state)) \
    )

#define BOOST_PARAMETER_SEQ_ZERO_PRED(d, state) \
    BOOST_PP_BOOL(BOOST_PP_TUPLE_ELEM(2, 1, state))

#define BOOST_PARAMETER_SEQ_ZERO(n) \
    BOOST_PP_TUPLE_ELEM( \
        2 \
      , 0 \
      , BOOST_PP_WHILE( \
            BOOST_PARAMETER_SEQ_ZERO_PRED \
          , BOOST_PARAMETER_SEQ_ZERO_NEXT_STATE \
          , (BOOST_PP_SEQ_NIL, n) \
        ) \
    )

// Given the main input sequence in_seq and a sequence c_seq
// that corresponds to a necessary function overload,
// BOOST_PARAMETER_SEQ_INC finds the sequence that corresponds to
// the next necessary function overload.

#define BOOST_PARAMETER_SEQ_INC_NEXT_STATE(d, state) \
    ( \
        BOOST_PP_TUPLE_ELEM(4, 0, state) \
      , BOOST_PP_TUPLE_ELEM(4, 1, state) \
      , BOOST_PP_IIF( \
            BOOST_PP_TUPLE_ELEM(4, 3, state) \
          , BOOST_PP_IIF( \
                BOOST_PP_BITOR( \
                    BOOST_PP_SEQ_ELEM( \
                        BOOST_PP_SEQ_SIZE( \
                            BOOST_PP_TUPLE_ELEM(4, 2, state) \
                        ) \
                      , BOOST_PP_TUPLE_ELEM(4, 1, state) \
                    ) \
                  , BOOST_PP_COMPL( \
                        BOOST_PP_SEQ_ELEM( \
                            BOOST_PP_SEQ_SIZE( \
                                BOOST_PP_TUPLE_ELEM(4, 2, state) \
                            ) \
                          , BOOST_PP_TUPLE_ELEM(4, 0, state) \
                        ) \
                    ) \
                ) \
              , BOOST_PP_IIF( \
                    BOOST_PP_EQUAL( \
                        BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
                      , BOOST_PP_DEC( \
                            BOOST_PP_SEQ_SIZE( \
                                BOOST_PP_TUPLE_ELEM(4, 1, state) \
                            ) \
                        ) \
                    ) \
                  , BOOST_PP_SEQ_PUSH_BACK( \
                        BOOST_PP_SEQ_PUSH_BACK( \
                            BOOST_PP_TUPLE_ELEM(4, 2, state) \
                          , 0 \
                        ) \
                      , 0 \
                    ) \
                  , BOOST_PP_SEQ_PUSH_BACK( \
                        BOOST_PP_TUPLE_ELEM(4, 2, state) \
                      , 0 \
                    ) \
                ) \
              , BOOST_PP_SEQ_PUSH_BACK(BOOST_PP_TUPLE_ELEM(4, 2, state), 1) \
            ) \
          , BOOST_PP_SEQ_PUSH_BACK( \
                BOOST_PP_TUPLE_ELEM(4, 2, state) \
              , BOOST_PP_SEQ_ELEM( \
                    BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
                  , BOOST_PP_TUPLE_ELEM(4, 1, state) \
                ) \
            ) \
        ) \
      , BOOST_PP_BITAND( \
            BOOST_PP_TUPLE_ELEM(4, 3, state) \
          , BOOST_PP_BITOR( \
                BOOST_PP_SEQ_ELEM( \
                    BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
                  , BOOST_PP_TUPLE_ELEM(4, 1, state) \
                ) \
              , BOOST_PP_COMPL( \
                    BOOST_PP_SEQ_ELEM( \
                        BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
                      , BOOST_PP_TUPLE_ELEM(4, 0, state) \
                    ) \
                ) \
            ) \
        ) \
    )

#define BOOST_PARAMETER_SEQ_INC_PRED(d, state) \
    BOOST_PP_IIF( \
        BOOST_PP_TUPLE_ELEM(4, 3, state) \
      , BOOST_PP_NOT_EQUAL( \
            BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
          , BOOST_PP_INC(BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 1, state))) \
        ) \
      , BOOST_PP_NOT_EQUAL( \
            BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 2, state)) \
          , BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(4, 1, state)) \
        ) \
    )

#define BOOST_PARAMETER_SEQ_INC(in_seq, c_seq) \
    BOOST_PP_TUPLE_ELEM( \
        4 \
      , 2 \
      , BOOST_PP_WHILE( \
            BOOST_PARAMETER_SEQ_INC_PRED \
          , BOOST_PARAMETER_SEQ_INC_NEXT_STATE \
          , ( \
                in_seq \
              , c_seq \
              , BOOST_PP_EMPTY() \
              , 1 \
            ) \
        ) \
    )

// Expands to "Tn const& pn," if the nth element in the sequence is 0,
// otherwise expands to "Tn & pn,".

#define BOOST_PARAMETER_FUN2_PARAM(z, n, seq) \
    BOOST_PP_CAT(T, n) \
    BOOST_PP_IF(BOOST_PP_SEQ_ELEM(n, seq), &, const&) \
    BOOST_PP_CAT(p, n),

// Generates the definition of each function overload.

#define BOOST_PARAMETER_FUN2_DEF(ret, name, c_seq, n, parameters) \
    BOOST_PP_CAT(BOOST_PARAMETER_FUN_TEMPLATE_HEAD, BOOST_PP_BOOL(n))(n) \
    ret \
        name( \
            BOOST_PP_REPEAT(n, BOOST_PARAMETER_FUN2_PARAM, c_seq) \
            BOOST_PARAMETER_MATCH_TYPE(n, parameters) kw = parameters() \
        ) \
    { \
        return BOOST_PP_CAT(name, _with_named_params)( \
            kw(BOOST_PP_ENUM_PARAMS(n, p)) \
        ); \
    }

#define BOOST_PARAMETER_FUN2_OVERLOAD_MACRO(r, state) \
    BOOST_PARAMETER_FUN2_DEF \
    ( \
        BOOST_PP_TUPLE_ELEM(5, 0, state) \
      , BOOST_PP_TUPLE_ELEM(5, 1, state) \
      , BOOST_PP_TUPLE_ELEM(5, 3, state) \
      , BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(5, 3, state)) \
      , BOOST_PP_TUPLE_ELEM(5, 4, state) \
    )

#define BOOST_PARAMETER_FUN2_OVERLOAD_NEXT_STATE(r, state) \
    ( \
        BOOST_PP_TUPLE_ELEM(5, 0, state) \
      , BOOST_PP_TUPLE_ELEM(5, 1, state) \
      , BOOST_PP_TUPLE_ELEM(5, 2, state) \
      , BOOST_PARAMETER_SEQ_INC( \
            BOOST_PP_TUPLE_ELEM(5, 2, state) \
          , BOOST_PP_TUPLE_ELEM(5, 3, state) \
        ) \
      , BOOST_PP_TUPLE_ELEM(5, 4, state) \
    )

#define BOOST_PARAMETER_FUN2_OVERLOAD_PRED(r, state) \
    BOOST_PP_NOT_EQUAL( \
        BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(5, 2, state)) \
      , BOOST_PP_DEC(BOOST_PP_SEQ_SIZE(BOOST_PP_TUPLE_ELEM(5, 3, state))) \
    )

// ret
//     The return type.
// name
//     The name of the function.
// seq
//     A Boost.Preprocessor sequence of 1's and 0's.  Each element corresponds
//     to a positional parameter; if the element is 1, the parameter is an
//     "out" parameter; otherwise it is an "in" parameter.
// num_req
//     The number of arguments required by the function.
// parameters
//     The corresponding boost::parameter::parameters instance.

#define BOOST_PARAMETER_MEMFUN2(ret, name, seq, num_req, parameters) \
    BOOST_PP_FOR( \
        ( \
            ret \
          , name \
          , seq \
          , BOOST_PARAMETER_SEQ_ZERO(num_req) \
          , parameters \
        ) \
      , BOOST_PARAMETER_FUN2_OVERLOAD_PRED \
      , BOOST_PARAMETER_FUN2_OVERLOAD_NEXT_STATE \
      , BOOST_PARAMETER_FUN2_OVERLOAD_MACRO \
    ) \
    template <class Params> \
    ret BOOST_PP_CAT(name, _with_named_params)(Params const& p)

#define BOOST_PARAMETER_FUN2(ret, name, seq, num_req, parameters) \
    template <class Params> \
    ret BOOST_PP_CAT(name, _with_named_params)(Params const& p); \
    BOOST_PARAMETER_MEMFUN2(ret, name, seq, num_req, parameters)

#endif // BOOST_PARAMETER_MACROS2_HPP
