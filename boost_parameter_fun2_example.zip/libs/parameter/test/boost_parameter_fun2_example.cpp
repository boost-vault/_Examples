// Copyright (C) 2006 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/graph/adjacency_list.hpp>
#include <boost/numeric/ublas/matrix_sparse.hpp>
#include "boost_parameter_fun2_example.hpp"

int main()
{
    typedef boost::adjacency_list<>
            Graph;
    typedef boost::graph_traits<Graph>::vertex_descriptor
            Vertex;

    Graph g;
    Vertex u = boost::add_vertex(g);
    Vertex v = boost::add_vertex(g);
    boost::numeric::ublas::mapped_matrix<double> m;
    double d = 98.6;

    foo::bar(g, u, v);
    foo::bar(
        foo::graph = g
      , foo::source = u
      , foo::target = v
    );
    foo::bar(g, u, v, m);
    foo::bar(
        foo::source = u
      , foo::target = v
      , foo::graph = g
      , m
    );
    foo::bar(
        foo::matrix = m
      , foo::source = u
      , foo::target = v
      , foo::graph = g
    );
    foo::bar(g, u, v, m, d);
    foo::bar(
        foo::matrix = m
      , foo::value = d
      , foo::source = u
      , foo::target = v
      , foo::graph = g
    );

    return 0;
}
