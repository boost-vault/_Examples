// Copyright (C) 2006 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_PARAMETER_FUN2_EXAMPLE_HPP
#define BOOST_PARAMETER_FUN2_EXAMPLE_HPP

#include <boost/type_traits/remove_const.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/parameter.hpp>
#include <boost/parameter/macros2.hpp>
#include <boost/numeric/ublas/matrix.hpp>

namespace foo {

BOOST_PARAMETER_KEYWORD(tag, graph)
BOOST_PARAMETER_KEYWORD(tag, source)
BOOST_PARAMETER_KEYWORD(tag, target)
BOOST_PARAMETER_KEYWORD(tag, matrix)
BOOST_PARAMETER_KEYWORD(tag, value)

struct bar_parameters
  : boost::parameter::parameters<
        boost::parameter::required<tag::graph>
      , boost::parameter::required<tag::source>
      , boost::parameter::required<tag::target>
      , boost::parameter::optional<tag::matrix>
      , boost::parameter::optional<tag::value>
    >
{
};

template <typename Graph, typename Matrix>
void baz(
    Graph& g
  , typename boost::graph_traits<Graph>::vertex_descriptor u
  , typename boost::graph_traits<Graph>::vertex_descriptor v
  , Matrix& m
)
{
}

BOOST_PARAMETER_FUN2(
    void
  , bar
  , (1)(0)(0)(1)(0)
  , 3
  , bar_parameters
)
{
    typedef typename boost::remove_const<
                typename boost::remove_reference<
                    typename boost::parameter::binding<
                        Params
                      , tag::graph
                    >::type
                >::type
            >::type
            Graph;
    typedef typename boost::remove_const<
                typename boost::remove_reference<
                    typename boost::parameter::binding<
                        Params
                      , tag::value
                      , unsigned int
                    >::type
                >::type
            >::type
            IntType;
    typedef boost::numeric::ublas::matrix<IntType>
            DefaultMatrix;
    typedef typename boost::remove_const<
                typename boost::parameter::binding<
                    Params
                  , tag::matrix
                  , DefaultMatrix&
                >::type
            >::type
            Matrix;

    Graph& g = p[graph];
    typename boost::graph_traits<Graph>::vertex_descriptor u = p[source];
    typename boost::graph_traits<Graph>::vertex_descriptor v = p[target];
    DefaultMatrix dm;
    Matrix m = p[matrix | dm];

    baz(g, u, v, m);
}
} // namespace foo

#endif // BOOST_PARAMETER_FUN2_EXAMPLE_HPP
