// Copyright (C) 2006 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <boost/ref.hpp>
#include <boost/random/mersenne_twister.hpp>
#include "boost_parameter_random_example.hpp"

class ExampleRNG
{
    unsigned int _counter;

 public:
    ExampleRNG()
      : _counter(0)
    {
    }

    unsigned int operator()()
    {
        return ++_counter;
    }
};

int main()
{
#ifndef _MINIMAL_EXAMPLE
#ifdef _CONST_RNG
    const boost::mt19937 m_rng = boost::mt19937();
#else
    boost::mt19937 m_rng;
#endif
    std::cout << "Named: " << example::foo(
        example::rng_engine = m_rng
      , example::min = 12
      , example::max = 24
    ) << std::endl;
#ifdef _NO_REF
    std::cout << "Unnamed: " << example::foo(m_rng, 12, 24);
#else
    std::cout << "Unnamed: " << example::foo(boost::ref(m_rng), 12, 24);
#endif
#else
    ExampleRNG e_rng;
    std::cout << "Named: " << example::bar(
        example::rng_engine = e_rng
      , example::min = 12
      , example::max = 24
    ) << std::endl;
#ifdef _NO_REF
    std::cout << "Unnamed: " << example::bar(e_rng, 12, 24);
#else
    std::cout << "Unnamed: " << example::bar(boost::ref(e_rng), 12, 24);
#endif
    std::cout << std::endl;
#endif

    return 0;
}
