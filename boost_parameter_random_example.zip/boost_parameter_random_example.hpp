// Copyright (C) 2006 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_PARAMETER_RANDOM_EXAMPLE_HPP
#define BOOST_PARAMETER_RANDOM_EXAMPLE_HPP

#include <boost/type_traits/remove_const.hpp>
#include <boost/parameter.hpp>
#include <boost/random/uniform_int.hpp>
#include <boost/random/variate_generator.hpp>

namespace example {

BOOST_PARAMETER_KEYWORD(tag, rng_engine)
BOOST_PARAMETER_KEYWORD(tag, min)
BOOST_PARAMETER_KEYWORD(tag, max)
BOOST_PARAMETER_KEYWORD(tag, factor)
BOOST_PARAMETER_KEYWORD(tag, addend)

struct foo_parameters
  : boost::parameter::parameters<
        boost::parameter::required<tag::rng_engine>
      , boost::parameter::required<tag::min>
      , boost::parameter::required<tag::max>
      , boost::parameter::optional<tag::factor>
      , boost::parameter::optional<tag::addend>
    >
{
};

BOOST_PARAMETER_FUN(unsigned int, foo, 3, 5, foo_parameters)
{
    typedef typename boost::remove_const<
                typename boost::parameter::binding<
                    Params
                  , tag::rng_engine
                >::type
            >::type
            RNGEngine;
    typedef boost::uniform_int<unsigned int>
            RNGDist;
    typedef boost::variate_generator<RNGEngine,RNGDist>
            RNG;

    RNGEngine rng_e = p[rng_engine];
    RNG       rng(rng_e, RNGDist(p[min], p[max]));

    return rng() * p[factor | 10] + p[addend | 5];
}

BOOST_PARAMETER_FUN(unsigned int, bar, 3, 5, foo_parameters)
{
    typedef typename boost::remove_const<
                typename boost::parameter::binding<
                    Params
                  , tag::rng_engine
                >::type
            >::type
            RNGEngine;

    RNGEngine    rng   = p[rng_engine];
    unsigned int p_min = p[min];

    return (rng() * (p[max] - p_min) + p_min) * p[factor | 10] + p[addend | 5];
}
} // namespace test

#endif // BOOST_PARAMETER_RANDOM_EXAMPLE_HPP
