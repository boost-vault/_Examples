#include <boost/config.hpp>
#include <boost/detail/workaround.hpp>

#if defined _MSC_VER
   #pragma warning (pop)
#endif

#if BOOST_WORKAROUND(__BORLANDC__, BOOST_TESTED_AT(0x564))
#  pragma warn .8026
#  pragma warn .8027
#endif
